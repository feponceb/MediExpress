package none.MediExpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediExpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediExpressApplication.class, args);
	}

}
