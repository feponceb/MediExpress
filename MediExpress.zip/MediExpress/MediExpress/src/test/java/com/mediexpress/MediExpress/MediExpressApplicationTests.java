package com.mediexpress.MediExpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
